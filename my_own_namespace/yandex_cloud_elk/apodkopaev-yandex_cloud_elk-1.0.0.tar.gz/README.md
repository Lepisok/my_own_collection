# Ansible Collection - apodkopaev.yandex_cloud_elk

This a test collection

The collection contains a single module my_own_module that puts content to a text file at path.

The single_task_role contains a trivial test of this module.
